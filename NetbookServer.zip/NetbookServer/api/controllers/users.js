const mongoose = require('mongoose');
const Book = require('../models/book');
const User = require('../models/user');

exports.get_all_users = (req, res, next) => {
    User.find().select('-__v').exec().then((docs) => {
        console.log(docs);
        const response = {
            count: docs.length,
            users: docs
        };
        res.status(200).json(response)
    }).catch((err) => {
        console.log(err);
        res.status(500).json({ error: err })
    });
}

exports.create_user = (req, res, next) => {
    console.log(req);
    const user = new User({
        _id: new mongoose.Types.ObjectId(),
        user_name: req.body.user_name,
        password: req.body.password,
        repeat_password: req.body.repeat_password,
        mail: req.body.mail,
        read_books: req.body.read_books
    });

    user.save().then((result) => {
        res.status(201).json({
            message: 'Usuario creado!',
            createUser: user
        });
    }).catch((err) => {
        console.log(err);
        res.status(500).json({ error: err })
    });
}

exports.get_user = (req, res, next) => {
    const user_id = req.params.id;

    User.findById(user_id).select('-__v').exec().then((doc) => {
        console.log(doc);
        if (doc) {
            res.status(200).json(doc);
        } else {
            res.status(404).json({ message: 'User id not found.'})
        }
    }).catch((err) => {
        console.log(err);
        res.status(500).json({ error: err });
    });
}

exports.get_saved_books = (req, res, next) => {
    const user_name = req.params.user_name;
    User.find({user_name: user_name}).select('saved_books').exec().then((doc) => {
        console.log(doc);
        if (doc) {
            res.status(200).json(doc);
        } else {
            res.status(404).json({ message: 'User name not found.'})
        }
    }).catch((err) => {
        console.log(err);
        res.status(500).json({ error: err });
    });
}

exports.get_read_books = (req, res, next) => {
    const user_name = req.params.user_name;
    User.find({user_name: user_name}).select('read_books').exec().then((doc) => {
        console.log(doc);
        if (doc) {
            res.status(200).json(doc);
        } else {
            res.status(404).json({ message: 'User name not found.'})
        }
    }).catch((err) => {
        console.log(err);
        res.status(500).json({ error: err });
    });
}

exports.get_user_by_username_password =(req, res, next) => {
    const user_name = req.params.user_name;
    const password = req.params.password;

    User.find({user_name: user_name, password: password}).exec().then((doc) => {
        console.log(doc);
        if (doc) {
            res.status(200).json({ message: 'User name and password are corrects.'});
        } else {
            res.status(404).json({ message: 'User name or password is incorrect.'})
        }
    }).catch((err) => {
        console.log(err);
        res.status(500).json({ error: err });
    });
}

exports.verify_mail = (req, res, next) => {
    const mail = req.params.mail;

    User.find({mail: mail}).exec().then((doc) => {
        console.log(doc);
        if (doc) {
            res.status(200).json({ message: 'Mail already used.'});
        } else {
            res.status(404).json({ message: 'There is no user_name with that mail'})
        }
    }).catch((err) => {
        console.log(err);
        res.status(500).json({ error: err });
    });
}

exports.verify_user_name = (req, res, next) => {
    const user_name = req.params.user_name;

    User.find({user_name: user_name}).exec().then((doc) => {
        console.log(doc);
        if (doc) {
            res.status(200).json({ message: 'User exists.'});
        } else {
            res.status(404).json({ message: 'User do not exist.'})
        }
    }).catch((err) => {
        console.log(err);
        res.status(500).json({ error: err });
    });
}

exports.save_book = (req, res, next) => {
    const user_name = req.params.user_name;
    const book_id = req.params.book_id;

    Book.findById(book_id).select('-__v').exec().then((doc) => {
        console.log(doc);
        if (doc) {
            User.update({user_name: user_name}, { $push: {saved_books: {book: doc}} }).exec().then((result) => {
                res.status(200).json({message: "Book " + book_id + " has been added to the saved list user."});
            }).catch((err) => {
                console.log(err);
                res.status(500).json({ error: err });
            });

        } else {
            res.status(404).json({ message: 'Book id not found.'})
        }
    }).catch((err) => {
        console.log(err);
        res.status(500).json({ error: err });
    });
}

exports.add_read_book = (req, res, next) => {
    const user_name = req.params.user_name;
    const _id = req.params.book_id;
    const page = req.params.page;
    const finished = req.params.finished;
    const date = req.params.date;

    User.update({user_name: user_name}, { $push: {read_books: {_id: _id, page: page, finished: finished, date: date}} }).exec().then((result) => {
        res.status(200).json({message: "Book " + _id + " has been added to the list read books."});
    }).catch((err) => {
        console.log(err);
        res.status(500).json({ error: err });
    });
}

exports.update_read_book = (req, res, next) => {
    const user_name = req.params.user_name;
    const _id = req.params.book_id;
    const page = req.params.page;
    const finished = req.params.finished;
    const date = req.params.date;

    User.update({user_name: user_name}, { $set: {read_books: [{_id: _id, page: page, finished: finished, date: date}]}}).exec().then((result) => {
        res.status(200).json(result);
    }).catch((err) => {
        console.log(err);
        res.status(500).json({ error: err });
    });

    res.status(200).json({
        message: 'Read book with book id '+ _id + ' successfully update.'
    });
}

exports.delete_user = (req, res, next) => {
    const user_id = req.params.id;

    User.remove({ _id: user_id }).exec().then((result) => {
        res.status(200).json(result);
    }).catch((err) => {
        console.log(err);
        res.status(500).json({ error: err });
    });
}