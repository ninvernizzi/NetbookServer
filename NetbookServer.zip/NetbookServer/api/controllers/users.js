const mongoose = require('mongoose');
const User = require('../models/user');

exports.get_all_users = (req, res, next) => {
    User.find().select('-__v').exec().then((docs) => {
        console.log(docs);
        const response = {
            count: docs.length,
            users: docs
        };
        res.status(200).json(response)
    }).catch((err) => {
        console.log(err);
        res.status(500).json({ error: err })
    });
}

exports.create_user = (req, res, next) => {
    console.log(req);
    const user = new User({
        _id: new mongoose.Types.ObjectId(),
        user_name: req.body.user_name,
        password: req.body.password,
        mail: req.body.mail,
        books: req.body.books
    });

    user.save().then((result) => {
        res.status(201).json({
            message: 'Usuario creado!',
            createUser: user
        });
    }).catch((err) => {
        console.log(err);
        res.status(500).json({ error: err })
    });
}

exports.get_user = (req, res, next) => {
    const user_id = req.params.id;

    Evento.findById(user_id).select('-__v').exec().then((doc) => {
        console.log(doc);
        if (doc) {
            res.status(200).json(doc);
        } else {
            res.status(404).json({ message: 'User id not found.'})
        }
    }).catch((err) => {
        console.log(err);
        res.status(500).json({ error: err });
    });
}

exports.update_user = (req, res, next) => {
    const user_id = req.params.id;

    const updateOps = {};
    for (const ops of req.body) {
        updateOps[ops.propName] = ops.value;
    }

    User.update({_id: user_id}, { $set: updateOps }).exec().then((result) => {
        res.status(200).json(result);
    }).catch((err) => {
        console.log(err);
        res.status(500).json({ error: err });
    });

    res.status(200).json({
        message: 'User with user id '+ user_id + ' successfully update.'
    });
}

exports.delete_user = (req, res, next) => {
    const user_id = req.params.id;

    Evento.remove({ _id: user_id }).exec().then((result) => {
        res.status(200).json(result);
    }).catch((err) => {
        console.log(err);
        res.status(500).json({ error: err });
    });
}