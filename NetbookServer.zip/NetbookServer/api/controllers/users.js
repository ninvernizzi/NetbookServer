const mongoose = require('mongoose');
const User = require('../models/user');

exports.get_all_users = (req, res, next) => {
    User.find().select('-__v').exec().then((docs) => {
        console.log(docs);
        const response = {
            count: docs.length,
            users: docs
        };
        res.status(200).json(response)
    }).catch((err) => {
        console.log(err);
        res.status(500).json({ error: err })
    });
}

exports.create_user = (req, res, next) => {
    console.log(req);
    const user = new User({
        _id: new mongoose.Types.ObjectId(),
        user_name: req.body.user_name,
        password: req.body.password,
        repeat_password: req.body.repeat_password,
        mail: req.body.mail,
        read_books: req.body.read_books
    });

    user.save().then((result) => {
        res.status(201).json({
            message: 'Usuario creado!',
            createUser: user
        });
    }).catch((err) => {
        console.log(err);
        res.status(500).json({ error: err })
    });
}

exports.get_user = (req, res, next) => {
    const user_id = req.params.id;

    User.findById(user_id).select('-__v').exec().then((doc) => {
        console.log(doc);
        if (doc) {
            res.status(200).json(doc);
        } else {
            res.status(404).json({ message: 'User id not found.'})
        }
    }).catch((err) => {
        console.log(err);
        res.status(500).json({ error: err });
    });
}

exports.get_read_books = (req, res, next) => {
    const user_name = req.params.user_name;
    User.find({user_name: user_name}).select('read_books').exec().then((doc) => {
        console.log(doc);
        if (doc) {
            res.status(200).json(doc);
        } else {
            res.status(404).json({ message: 'User name not found.'})
        }
    }).catch((err) => {
        console.log(err);
        res.status(500).json({ error: err });
    });
}

exports.get_user_by_username_password =(req, res, next) => {
    const user_name = req.params.user_name;
    const password = req.params.password;

    User.find({user_name: user_name, password: password}).exec().then((doc) => {
        console.log(doc);
        if (doc) {
            res.status(200).json({ message: 'User name and password are corrects.'});
        } else {
            res.status(404).json({ message: 'User name or password is incorrect.'})
        }
    }).catch((err) => {
        console.log(err);
        res.status(500).json({ error: err });
    });
}

exports.update_user = (req, res, next) => {
    const user_id = req.params.id;

    const updateOps = {};
    for (const ops of req.body.read_books) {
        updateOps[ops.propName] = ops.value;
    }

    User.update({_id: user_id}, { $push: {read_books: {updateOps}} }).exec().then((result) => {
        res.status(200).json(result);
    }).catch((err) => {
        console.log(err);
        res.status(500).json({ error: err });
    });

    res.status(200).json({
        message: 'User with user id '+ user_id + ' successfully update.'
    });
}

exports.add_book = (req, res, next) => {
    const user_name = req.params.user_name;
    const book_id = req.params.book_id;


    User.update({user_name: user_name}, { $push: {read_books: {_id: book_id}} }).exec().then((result) => {
        res.status(200).json(result);
    }).catch((err) => {
        console.log(err);
        res.status(500).json({ error: err });
    });

    res.status(200).json({
        message: 'Book with book_id '+ book_id + ' successfully inserted.'
    });
}

exports.delete_user = (req, res, next) => {
    const user_id = req.params.id;

    User.remove({ _id: user_id }).exec().then((result) => {
        res.status(200).json(result);
    }).catch((err) => {
        console.log(err);
        res.status(500).json({ error: err });
    });
}