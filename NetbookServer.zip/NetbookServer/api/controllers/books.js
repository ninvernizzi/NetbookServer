const mongoose = require('mongoose');
const Book = require('../models/book');

exports.get_all_books = (req, res, next) => {
    Book.find().select('-__v').exec().then((docs) => {
        console.log(docs);
        const response = {
            count: docs.length,
            users: docs
        };
        res.status(200).json(response)
    }).catch((err) => {
        console.log(err);
        res.status(500).json({ error: err })
    });
}

exports.insert_book = (req, res, next) => {
    console.log(req);
    const book = new Book({
        _id: req.body._id,
        title: req.body.title,
        original_title: req.body.original_title,
        author: req.body.author,
        year: req.body.year,
        genre: req.body.genre,
        subgenre: req.body.subgenre,
        number_of_pages: req.body.number_of_pages,
        cover: req.body.cover,
        book: req.body.book,
        description: req.body.description
    });

    book.save().then((result) => {
        res.status(201).json({
            message: 'Libro insertado!',
            insertBook: book
        });
    }).catch((err) => {
        console.log(err);
        res.status(500).json({ error: err })
    });
}

exports.get_book = (req, res, next) => {
    const book_id = req.params.id;

    Book.findById(book_id).select('-__v').exec().then((doc) => {
        console.log(doc);
        if (doc) {
            res.status(200).json(doc);
        } else {
            res.status(404).json({ message: 'Book id not found.'})
        }
    }).catch((err) => {
        console.log(err);
        res.status(500).json({ error: err });
    });
}

exports.update_book = (req, res, next) => {
    const book_id = req.params.id;

    const updateOps = {};
    for (const ops of req.body) {
        updateOps[ops.propName] = ops.value;
    }

    Book.update({_id: book_id}, { $set: updateOps }).exec().then((result) => {
        res.status(200).json(result);
    }).catch((err) => {
        console.log(err);
        res.status(500).json({ error: err });
    });

    res.status(200).json({
        message: 'Book with book id '+ book_id + ' successfully update.'
    });
}

exports.delete_book = (req, res, next) => {
    const book_id = req.params.id;

    Book.remove({ _id: book_id }).exec().then((result) => {
        res.status(200).json(result);
    }).catch((err) => {
        console.log(err);
        res.status(500).json({ error: err });
    });
}