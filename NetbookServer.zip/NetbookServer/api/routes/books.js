const express = require('express');
const router = express.Router();
const multer = require('multer');
const UsersController = require('../controllers/books')

router.get('/', UsersController.get_all_books);

router.post('/insert_book', UsersController.insert_book);

router.get('/:id', UsersController.get_book);

router.patch('/:id', UsersController.update_book);

router.delete('/:id', UsersController.delete_book);

module.exports = router;