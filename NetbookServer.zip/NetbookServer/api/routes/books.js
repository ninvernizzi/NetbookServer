const express = require('express');
const router = express.Router();
const multer = require('multer');
const BooksController = require('../controllers/books')

router.get('/', BooksController.get_all_books);

router.post('/insert_book', BooksController.insert_book);

router.get('/getBook/:id', BooksController.get_book);

router.patch('/:id', BooksController.update_book);

router.delete('/:id', BooksController.delete_book);

module.exports = router;