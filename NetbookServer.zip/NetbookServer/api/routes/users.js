const express = require('express');
const router = express.Router();
const multer = require('multer');
const UsersController = require('../controllers/users')

router.get('/', UsersController.get_all_users);

router.post('/create_user', UsersController.create_user);

router.get('/getReadBooks/:user_name', UsersController.get_read_books);

router.get('/getUser/:id', UsersController.get_user);

router.get('/login/:user_name/:password', UsersController.get_user_by_username_password);

router.patch('/addBook/:user_name/:book_id', UsersController.add_book);

router.delete('/:id', UsersController.delete_user);

module.exports = router;