const express = require('express');
const router = express.Router();
const multer = require('multer');
const UsersController = require('../controllers/users')

router.get('/', UsersController.get_all_users);

router.post('/create_user', UsersController.create_user);

router.get('/:id', UsersController.get_user);

router.patch('/:id', UsersController.update_user);

router.delete('/:id', UsersController.delete_user);

module.exports = router;