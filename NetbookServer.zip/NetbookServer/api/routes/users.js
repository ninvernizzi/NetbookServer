const express = require('express');
const router = express.Router();
const multer = require('multer');
const UsersController = require('../controllers/users')

router.get('/', UsersController.get_all_users);

router.post('/create_user', UsersController.create_user);

router.get('/getUser/:id', UsersController.get_user);

router.get('/verifyMail/:mail', UsersController.verify_mail);

router.get('/verifyUserName/:user_name', UsersController.verify_user_name);

router.get('/getSavedBooks/:user_name', UsersController.get_saved_books);

router.get('/getReadBooks/:user_name', UsersController.get_read_books);

router.get('/login/:user_name/:password', UsersController.get_user_by_username_password);

router.patch('/saveBook/:user_name/:book_id', UsersController.save_book);

router.patch('/updateReadBook/:user_name/:book_id/:page/:finished/:date', UsersController.update_read_book);

router.patch('/addReadBook/:user_name/:book_id/:page/:finished/:date', UsersController.add_read_book);

router.delete('/:id', UsersController.delete_user);

module.exports = router;