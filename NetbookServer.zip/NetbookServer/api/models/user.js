const mongoose = require("mongoose");

const user_schema = mongoose.Schema({
    _id: mongoose.Schema.Types.ObjectId,
    user_name: {type: String, required: true},
    password: {type: String, required: true},
    repeat_password: {type: String, required: true},
    mail: {type: String, required: true},
    read_books: {type: Array, required: false}
});

module.exports = mongoose.model('User', user_schema);