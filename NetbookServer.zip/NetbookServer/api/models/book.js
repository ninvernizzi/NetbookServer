const mongoose = require("mongoose");

const book_schema = mongoose.Schema({
    _id: mongoose.Schema.Types.ObjectId,
    title: {type: String, required: true},
    original_title: {type: String, required: true},
    author: {type: Array, required: true},
    year: {type: String, required: true},
    genre: {type: String, required: true},
    subgenre: {type: Array, required: true},
    number_of_pages: {type: String, required: true},
    cover: {type: String, required: true},
    book: {type: String, required: true},
    description: {type: String, required: true}
});

module.exports = mongoose.model('Book', book_schema);
