const express = require('express');
const app = express();
const morgan = require('morgan');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');

const users_routes = require('./api/routes/users');
const books_routes = require('./api/routes/books');

 // mongoose.connect('mongodb+srv://smartcar:paula1234%24@smartcar-60ejd.mongodb.net/test?retryWrites=false');
 mongoose.connect('mongodb://prios:46940309pau@cluster0-shard-00-00-cdw6l.mongodb.net:27017,cluster0-shard-00-01-cdw6l.mongodb.net:27017,cluster0-shard-00-02-cdw6l.mongodb.net:27017/test?ssl=true&replicaSet=Cluster0-shard-0&authSource=admin&retryWrites=false');

app.use(morgan('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// CORS Allow
app.use((req, res, next) => {
    res.header('Allow-Control-Allow-Origin', '*');
    res.header('Allow-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
    res.header('Access-Control-Allow-Origin','*');

    if(req.method === 'OPTIONS') {
        res.header('Allow-Control-Allow-Methods', 'PUT, POST, GET, PATCH, DELETE');
        return res.status(200).json({});
    }
    next();
});

// Rutas
app.use('/users', users_routes);
app.use('/books', books_routes);

app.use((req, res, next) => {
    const error = new Error('Not Found');
    error.status = 404;
    next(error);    
});

app.use((error, req, res, next) => {
    res.status(error.status || 500);
    res.json({
        error: error.message
    });
});

module.exports = app;