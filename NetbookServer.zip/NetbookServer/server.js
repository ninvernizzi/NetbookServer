const http = require('http');
const app = require('./netbook_app');

const port = process.env.PORT || 3000;

const server = http.createServer(app);

server.listen(port, '192.168.1.46');
